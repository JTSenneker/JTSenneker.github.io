var config = {
    width: 970,
    height: 528,
    backgroundColor: 0xffffff,
    scene: [Spinner]
};
var wheelOptions = {
    slices: [
        {
            degrees: 90,
            color: 0x114d7d,
            text: "Customer 1",
            id: "one"
        },
        {
            degrees: 90,
            color: 0xe6e6e6,
            text: "Customer 2",
            id: "one"
        },
        {
            degrees: 90,
            color: 0x043257,
            text: "Customer 3",
            id: "one"
        },
        {
            degrees: 90,
            color: 0x4d4d4d,
            text: "Customer 4",
            id: "one"
        }
    ],
    rotationTimeRange: {
        min: 3000,
        max: 4000
    },
    wheelRounds: {
        min: 2,
        max: 5
    },
    strokeColor: 0xffffff,
    strokeWidth: 2,
    wheelRadius: 160,
    remainingDegrees: [0, 1, 2, 3],
    canSpin: true
};

window.onload = function () {
    var game = new Phaser.Game(config);
};